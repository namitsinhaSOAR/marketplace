import copy
import json
from functools import reduce
from typing import Hashable

import chardet

from .exceptions import InternalJSONDecoderError
from .utils import is_python_37


def convert_dict_to_json_result_dict(
    json_result,
    title_key='Entity',
    results_key='EntityResult',
):
    """Convert key, value JSON result to JSON result object list and
        organize entity json result object to set format.

    Transform a dict to json result::

        {k1: v1, k2:v2, ...} =>
        [
            {
                title_key: k1,
                result_key: v1
            },
            {
                title_key: k2,
                result_key: v1
            }
            ...
        ]


    Args:
        json_result (dict[str, Any] | str): Key, val JSON result
        title_key (str):
            The key under which the name of each key will be. (e.g. 'Entity')
        result_key (str):
            The key under which the name of each value will be.
            (e.g. 'EntityResult')

    Examples:
        The default example is the entity result json format where
        `title_key='Entity'`, `results_key='EntityResult'`::

            [
                {
                    'Entity': 'key1 in json_result',
                    'EntityResult: {
                        json_result['key1']
                    }
                },
                {
                    'Entity': 'key2 in json_result',
                    'EntityResult: {
                        json_result['key2']
                    }
                }
            ]


    Returns:
        (list[dict[str, Any]]) List of entity JSON result objects

    Raises:
        InternalJSONDecoderError:
            if json_result is a str and could not be parsed to dict
            using json.loads()
        ValueError:
            if the json_result is not a dict
            (the check is done after loading it from string if needed)
    """
    try:
        if isinstance(json_result, str):
            json_result = json.loads(json_result)

    except json.JSONDecodeError as e:
        raise InternalJSONDecoderError(
            'Could not parse the json result from str to dict'
        )

    if not isinstance(json_result, dict):
        raise ValueError(
            'Attempting to convert wrong type {} '.format(type(json_result)) +
            'to list[dict].\n The json_result param must be a dict or a string '
            'that can be parsed to a dict to be converted to a list of dicts.'
        )

    return [{title_key: k, results_key: v} for k, v in json_result.items()]


def construct_csv(list_of_dicts):
    """Constructs a CSV from a list of dictionaries.

    Args:
        list_of_dicts (list[dict]): The list of dictionaries to add to the CSV.

    Returns:
        list[str]: The CSV formatted list.
    """
    csv_output = []
    if not list_of_dicts:
        return csv_output
    headers = reduce(set.union, map(set, map(dict.keys, list_of_dicts)))
    unicode_headers = []
    for header in headers:
        header = adjust_to_csv(header)
        header = get_unicode(header)
        unicode_headers.append(header)
    csv_output.append(u",".join(unicode_headers))
    for result in list_of_dicts:
        csv_row = []
        for header in headers:
            cell_value = result.get(header)
            cell_value = adjust_to_csv(cell_value)
            cell_value = get_unicode(cell_value)

            # Replace problematic commas
            cell_value = cell_value.replace(u',', u' ')
            # Append values to the row
            csv_row.append(cell_value)
        # Append row to the output
        csv_output.append(u",".join(csv_row))
    return csv_output


def adjust_to_csv(value):
    """Adjusts a value to be suitable for inclusion in a CSV.

    Args:
        value (Any): The value to adjust.

    Returns:
        str: The adjusted value.
    """
    if value is None:
        return ""
    return value


def dict_to_flat(target_dict):
    """
    Receives nested dictionary and returns it as a flat dictionary.

    Args:
        target_dict (dict): The dictionary to flatten.

    Returns:
        dict: The flattened dictionary.
    """
    target_dict = copy.deepcopy(target_dict)

    def expand(raw_key, raw_value):
        """
        Private recursive function to expand a nested dictionary.

        Args:
            raw_key (str): The key to expand.
            raw_value (str): The value to expand.

        Returns:
            list[tuple]: A list of tuples, each containing a key and a value.
        """
        key = raw_key
        value = raw_value
        if value is None:
            return [(get_unicode(key), u"")]
        elif isinstance(value, dict):
            # Handle dict type value
            return [(u"{0}_{1}".format(
                get_unicode(key),
                get_unicode(sub_key)
            ),
                     get_unicode(sub_value)) for sub_key, sub_value in
                dict_to_flat(value).items()]
        elif isinstance(value, list):
            # Handle list type value
            count = 1
            l = []
            items_to_remove = []
            for value_item in value:
                if isinstance(value_item, dict):
                    # Handle nested dict in list
                    l.extend(
                        [(u"{0}_{1}_{2}".format(
                            get_unicode(key),
                            get_unicode(count),
                            get_unicode(sub_key)
                        ),
                          sub_value)
                            for sub_key, sub_value in
                            dict_to_flat(value_item).items()]
                    )
                    items_to_remove.append(value_item)
                    count += 1
                elif isinstance(value_item, list):
                    l.extend(
                        expand(
                            get_unicode(key) + u'_' + get_unicode(count),
                            value_item
                        )
                    )
                    count += 1
                    items_to_remove.append(value_item)

            for value_item in items_to_remove:
                value.remove(value_item)

            for value_item in value:
                l.extend(
                    [(get_unicode(key) + u'_' + get_unicode(count), value_item)]
                )
                count += 1

            return l
        else:
            return [(get_unicode(key), get_unicode(value))]

    items = [item for sub_key, sub_value in target_dict.items() for item in
             expand(sub_key, sub_value)]
    return dict(items)


def flat_dict_to_csv(
    flat_dict,
    property_header=u"Property",
    value_header=u"Value"
):
    """
    Turns a flat dictionary into a list of strings in CSV format.
    The `property_header` and `value_header` arguments are used
    to customize the CSV header.

    Args:
        flat_dict (dict): The dictionary to convert to CSV format.
        property_header (str):
            The header for the property column. Defaults to "Property".
        value_header (str):
            The header for the value column. Defaults to "Value".

    Returns:
        list: The list of strings in CSV format.
    """
    csv_format = []
    csv_head = u"{}, {}".format(property_header, value_header)
    csv_format.append(csv_head)
    for key, value in flat_dict.items():
        safe_key = get_unicode(key)
        safe_value = get_unicode(value)
        csv_format.append(u"{0},{1}".format(safe_key, safe_value))
    return csv_format


def add_prefix_to_dict(given_dict, prefix):
    """
    Adds a prefix to the keys of a given dictionary.

    Args:
        given_dict (dict): The dictionary to add the prefix to.
        prefix (str): The prefix to add.

    Returns:
        dict: The dictionary with the prefix added to the keys.
    """
    return {u'{0}_{1}'.format(get_unicode(prefix), get_unicode(key)): value for
            key, value in given_dict.items()}


def add_prefix_to_dict_keys(target_dict, prefix):
    """
    Adds a prefix to the keys of a given dictionary.

    Args:
        target_dict (dict): The dictionary to add the prefix to.
        prefix (str): The prefix to add.

    Returns:
        dict: The dictionary with the prefix added to the keys.
    """
    result_dict = {}
    for key, val in target_dict.iteritems():
        new_key = u"{0}_{1}".format(get_unicode(prefix), get_unicode(key))
        result_dict[new_key] = val

    return result_dict


def get_unicode(value):
    """
    Get the unicode of a value.

    Args:
        value (Any): The value to convert to unicode.

    Returns:
        unicode (unicode): The unicode representation of `value`.

    """
    if is_python_37():
        return str(value)
    if isinstance(value, unicode):
        return value
    if not isinstance(value, basestring):
        # Validate that the cell is a basestring. If not convert it to string
        try:
            value = str(value)
        except Exception:
            value = u"Unable to get text representation of object"
    if value is None:
        # If the value is empty, leave the cell empty
        value = u""
    if isinstance(value, str):
        try:
            value = value.decode("utf8")
        except UnicodeDecodeError:
            try:
                encoding = chardet.detect(value).get('encoding')
                value = value.decode(encoding)
            except Exception:
                value = u"Unable to decode value (unknown encoding)"

    return value


def string_to_multi_value(string_value, delimiter=',', only_unique=False):
    """
    Convert a string containing a comma-separated list of values
    to a list of values.

    Args:
        string_value (str): The string to convert.
        delimiter (str, optional): The delimiter to split the string on.
            Defaults to ','.
        only_unique (bool, optional): If True, only include unique values in
            the returned list. Defaults to False.

    Returns:
        list: The list of values.
    """
    if not string_value:
        return []
    values = [single_value.strip() for single_value in
              string_value.split(delimiter) if single_value.strip()]
    if only_unique:
        seen = set()
        return [value for value in values if
                not (value in seen or seen.add(value))]
    return values


def convert_comma_separated_to_list(comma_separated, delimiter=','):
    """
    Convert a comma-separated string to a list of values.

    Args:
        delimiter: The parse the string with. Default is ','
        comma_separated (str): The comma-separated string to convert.

    Returns:
        list: The list of values.
    """
    return [item.strip() for item in
            comma_separated.split(delimiter)] if comma_separated else []


def convert_list_to_comma_string(values_list, delimiter=','):
    """
    Convert a list of values to a comma-separated string.

    Args:
        delimiter: The delimiter to be used in the string.
            Default = ','
        values_list (list): The list of values to convert.

    Returns:
        str: The comma-separated string.
    """
    return delimiter.join(
        str(v) for v in values_list
    ) if values_list and isinstance(
        values_list,
        list
    ) else values_list


def removeprefix(string, prefix):
    # type: (str, str) -> str
    """Self implementation for str.removeprefix() that exists in python 3.9+

    If the string starts with the prefix string, return string[len(prefix):].
    Otherwise, return a copy of the original string

    Args:
        string (str): The string to remove the prefix from
        prefix (str): The prefix to remove from the string

    Returns:
        The resulting string
    """
    return string[len(prefix):] if string.startswith(prefix) else string


def removesuffix(string, suffix):
    # type: (str, str) -> str
    """Self implementation for str.removesuffix() that exists in python 3.9+

    If the string ends with the suffix string, return string[:-len(prefix)].
    Otherwise, return a copy of the original string

    Args:
        string (str): The string to remove the prefix from
        suffix (str): The suffix to remove from the string

    Returns:
        The resulting string
    """
    return string[:-len(suffix)] if string.endswith(suffix) else string


def rename_dict_key(a_dict, current_key, new_key):
    # type: (dict, Hashable, Hashable) -> None
    """Rename a key in a dict in place

    Args:
        a_dict (dict): The dict to rename a key in
        current_key (Hashable): The key in a_dict to rename
        new_key (Hashable): The renamed key
    """
    a_dict[new_key] = a_dict[current_key]
    del a_dict[current_key]

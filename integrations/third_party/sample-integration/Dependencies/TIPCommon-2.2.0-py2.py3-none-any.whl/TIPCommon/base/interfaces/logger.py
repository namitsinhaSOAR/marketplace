import abc
from typing import TypeVar


class Logger(abc.ABC):
    """Logger interface for marketplace scripts.

    Use this interface in places the logger that is passed might be replaced ot mocked
    with a different implementation of this interface.

    Methods:
        - debug()
        - info()
        - warn()
        - error()
        - exception()
    """

    @abc.abstractmethod
    def debug(self, msg: str, *args, **kwargs) -> None:
        pass

    @abc.abstractmethod
    def info(self, msg: str, *args, **kwargs) -> None:
        pass

    @abc.abstractmethod
    def warn(self, warning_msg: str, *args, **kwargs) -> None:
        pass

    @abc.abstractmethod
    def error(self, error_msg: str, *args, **kwargs) -> None:
        pass

    @abc.abstractmethod
    def exception(self, ex: Exception, *args, **kwargs) -> None:
        pass


ScriptLogger = TypeVar("ScriptLogger", bound=Logger)

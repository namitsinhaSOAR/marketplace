# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""
exceptions
==========

A module containing all constant in use by TIPCommon package,
and common constant used in Marketplace Integrations

Usage Example::

    from TIPCommon.exceptions import ConnectorProcessingError
    raise ConnectorProcessingError('spam and eggs')
"""

class GeneralConnectorException(Exception):
    """ General Connector Exception"""
    ...


class ConnectorValidationError(GeneralConnectorException):
    """ Connector Validation Error"""
    ...


class ConnectorContextError(GeneralConnectorException):
    """ Connector Context Error"""
    ...


class ConnectorSetupError(GeneralConnectorException):
    """ Connector Initialization Error"""
    ...


class ConnectorProcessingError(GeneralConnectorException):
    """ Connector Processing Error"""
    ...

class ParameterValidationError(Exception):
    """Raised when a parameter is invalid."""

    def __init__(self, param_name, value, message, exception=None):
        msg = f"{exception}. {message}" if exception else message
        super().__init__(
            f"Invalid parameter: {param_name}, "
            f"value provided: {value}. "
            f"Error: {msg}"
        )
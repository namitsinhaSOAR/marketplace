"""Provides the Legacy API client implementation for interacting with Chronicle SOAR."""

# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from typing import TYPE_CHECKING

from TIPCommon.rest.custom_types import HttpMethod

from TIPCommon.consts import ACTION_NOT_SUPPORTED_PLATFORM_VERSION_MSG

from TIPCommon.exceptions import NotSupportedPlatformVersion

from .base_soar_api import BaseSoarApi

if TYPE_CHECKING:
    import requests
    from TIPCommon.types import ChronicleSOAR, SingleJson


class LegacySoarApi(BaseSoarApi):
    """Chronicle SOAR API client using legacy endpoints."""

    def save_attachment_to_case_wall(self) -> requests.Response:
        """Save an attachment to the case wall using legacy API."""
        endpoint = "api/external/v1/cases/AddEvidence/"
        payload = {
            "CaseIdentifier": self.params.case_id,
            "Base64Blob": self.params.base64_blob,
            "Name": self.params.name,
            "Description": self.params.description,
            "Type": self.params.file_type,
            "IsImportant": self.params.is_important,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_entity_data(self) -> requests.Response:
        """Get entity data using legacy API."""
        endpoint = "api/external/v1/entities/GetEntityData"
        payload = {
            "entityIdentifier": self.params.entity_identifier,
            "entityType": self.params.entity_type,
            "entityEnvironment": self.params.entity_environment,
            "lastCaseType": self.params.last_case_type,
            "caseDistributionType": self.params.case_distribution_type,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_full_case_details(self) -> requests.Response:
        """Get full case details using legacy API."""
        endpoint = f"api/external/v1/cases/GetCaseFullDetails/{self.params.case_id}"
        query_params = {"format": "snake"}
        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    def get_case_insights(self) -> requests.Response:
        """Get case insights using legacy API."""
        endpoint = f"api/external/v1/cases/insights/{self.params.case_id}"
        return self._make_request(HttpMethod.GET, endpoint)

    def get_installed_integrations_of_environment(self) -> requests.Response:
        """Get installed integrations of environment using legacy API."""
        endpoint = "api/external/v1/integrations/GetEnvironmentInstalledIntegrations"
        payload = {
            "name": (
                "*"
                if self.params.environment == "Shared Instances"
                else self.params.environment
            )
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_connector_cards(self) -> requests.Response:
        """Get connector cards using legacy API"""
        endpoint = "api/external/v1/connectors/cards"
        query_params = {"format": "snake"}
        return self._make_request(HttpMethod.GET, endpoint, params=query_params)

    def get_federation_cases(self) -> requests.Response:
        """Get federation cases using legacy API"""
        endpoint = "api/external/v1/federation/cases"
        params = {"continuationToken": self.params.continuation_token}

        return self._make_request(HttpMethod.GET, endpoint, params=params)

    def patch_federation_cases(self) -> requests.Response:
        """Get federation cases using legacy API"""
        endpoint = "api/external/v1/federation/cases/batch-patch"
        headers = {"AppKey": self.params.api_key} if self.params.api_key else None
        payload = {"cases": self.params.cases_payload}
        return self._make_request(
            HttpMethod.PATCH,
            endpoint,
            json_payload=payload,
            headers=headers,
        )

    def get_workflow_instance_card(self) -> requests.Response:
        """Get workflow instance card using legacy API"""
        endpoint = "api/external/v1/cases/GetWorkflowInstancesCards"
        payload = {
            "caseId": self.params.case_id,
            "alertIdentifier": self.params.alert_identifier,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def pause_alert_sla(self) -> requests.Response:
        """Pause alert sla"""
        endpoint = "api/external/v1/cases/PauseAlertSla"
        payload = {
            "caseId": self.params.case_id,
            "alertIdentifier": self.params.alert_identifier,
            "message": self.params.message,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def resume_alert_sla(self) -> requests.Response:
        """Resume alert sla"""
        endpoint = "api/external/v1/cases/ResumeAlertSla"
        payload = {
            "caseId": self.params.case_id,
            "alertIdentifier": self.params.alert_identifier,
            "message": self.params.message,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_case_overview_details(self) -> requests.Response:
        """Get case overview details"""
        case_id = self.params.case_id
        endpoint = f"api/external/v1/dynamic-cases/GetCaseDetails/{case_id}"
        return self._make_request(HttpMethod.GET, endpoint).json()

    def remove_case_tag(self) -> requests.Response:
        """Remove case tag"""
        endpoint = "api/external/v1/cases/RemoveCaseTag"
        payload = {
            "caseId": self.params.case_id,
            "tag": self.params.tag,
            "alertIdentifier": self.params.alert_identifier,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def change_case_description(self) -> requests.Response:
        """Change case description"""
        endpoint = "api/external/v1/cases/ChangeCaseDescription?format=snake"
        payload = {
            "case_id": self.params.case_id,
            "description": self.params.description,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def set_alert_priority(self) -> requests.Response:
        """Set alert priority"""
        endpoint = "api/external/v1/sdk/UpdateAlertPriority"
        payload = {
            "caseId": self.params.case_id,
            "alertIdentifier": self.params.alert_identifier,
            "priority": self.params.priority,
            "alertName": self.params.alert_name,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def set_case_score_bulk(self) -> requests.Response:
        """Set case score bulk"""
        endpoint = "api/external/v1/sdk/cases/score"
        payload = {
            "caseScores": [
                {
                    "caseId": self.params.case_id,
                    "score": self.params.score,
                }
            ],
        }
        return self._make_request(HttpMethod.PATCH, endpoint, json_payload=payload)

    def get_integration_full_details(self) -> requests.Response:
        """Get integration full details"""
        endpoint = "external/v1/store/GetIntegrationFullDetails"
        payload = {
            "integrationIdentifier": self.params.integration_identifier,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def _get_all_integration_instances(self) -> list[SingleJson]:
        """
        Private helper method to fetch all integration instances from the API.
        This encapsulates the common API call logic.
        """
        endpoint = "api/external/v1/integrations/GetOptionalIntegrationInstances"
        payload = {
            "environments": self.params.environments,
            "integrationIdentifier": self.params.integration_identifier
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_integration_instance_details_by_id(self) -> requests.Response:
        """Get integration instance details by instance id"""
        return self._get_all_integration_instances()

    def get_integration_instance_details_by_name(self) -> requests.Response:
        """Get integration instance details by instance name"""
        return self._get_all_integration_instances()

    def get_users_profile(self) -> requests.Response:
        """Get users profile"""
        endpoint = "api/external/v1/settings/GetUserProfiles"
        payload = {
            "searchTerm": self.params.search_term,
            "filterRole": self.params.filter_by_role,
            "requestedPage": self.params.requested_page,
            "pageSize": self.params.page_size,
            "shouldHideDisabledUsers": self.params.should_hide_disabled_users,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_investigator_data(self) -> requests.Response:
        """Get investigator data"""
        case_id = self.params.case_id
        endpoint = f"api/external/v1/investigator/GetInvestigatorData/{case_id}"
        return self._make_request(HttpMethod.GET, endpoint)

    def remove_entities_from_custom_list(self) -> requests.Response:
        """Remove entities from custom list"""
        endpoint = "api/external/v1/sdk/RemoveEntitiesFromCustomList"
        payload = self.params.list_entities_data
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def add_entities_to_custom_list(self) -> requests.Response:
        """Add entities to custom list"""
        endpoint = "api/external/v1/sdk/AddEntitiesToCustomList"
        payload = self.params.list_entities_data
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_traking_list_record(self) -> requests.Response:
        """Get traking list record"""
        endpoint = "api/external/v1/settings/GetTrackingListRecords"
        return self._make_request(HttpMethod.GET, endpoint)

    def get_traking_list_records_filtered(self) -> requests.Response:
        """Get traking list records filtered"""
        endpoint = "api/external/v1/settings/GetTrackingListRecordsFiltered"
        payload = {
            "environments": [self.chronicle_soar.environment],
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def execute_bulk_assign(self) -> requests.Response:
        """Execute bulk assign"""
        endpoint = "api/external/v1/cases/ExecuteBulkAssign"
        payload = {
            "casesIds": self.params.case_ids,
            "userName": self.params.user_name
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)


    def execute_bulk_close_case(self) -> requests.Response:
        """Execute bulk close case"""
        endpoint = "api/external/v1/cases/ExecuteBulkCloseCase"
        payload = {
            "casesIds": self.params.case_ids,
            "closeReason": self.params.close_reason,
            "rootCause": self.params.root_cause,
            "closeComment": self.params.close_comment
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_users_profile_cards(self) -> requests.Response:
        """Get users profile cards."""
        endpoint = "api/external/v1/settings/GetUserProfileCards"
        payload = {
            "searchTerm": self.params.search_term,
            "requestedPage": self.params.requested_page,
            "pageSize": self.params.page_size,
            "filterRole": self.params.filter_by_role,
            "filterDisabledUsers": self.params.filter_disabled_users,
            "filterSupportUsers": self.params.filter_support_users,
            "fetchOnlySupportUsers": self.params.fetch_only_support_users,
            "filterPermissionTypes": self.params.filter_permission_types,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_security_events(self) -> requests.Response:
        """Get security events"""
        return self.get_full_case_details()

    def get_entity_cards(self) -> requests.Response:
        """Get entity cards"""
        return self.get_full_case_details()

    def pause_case_sla(
        self, case_id: int, message: str | None = None
    ) -> requests.Response:
        raise NotSupportedPlatformVersion(ACTION_NOT_SUPPORTED_PLATFORM_VERSION_MSG)

    def resume_case_sla(self, case_id: int) -> requests.Response:
        raise NotSupportedPlatformVersion(ACTION_NOT_SUPPORTED_PLATFORM_VERSION_MSG)

    def rename_case(self) -> requests.Response:
        """Rename case"""
        endpoint = "api/external/v1/cases/RenameCase"
        payload = {
            "caseId": self.params.case_id,
            "title": self.params.case_title,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def add_comment_to_entity(self) -> requests.Response:
        """Add comment to entity"""
        endpoint = "api/external/v1/entities/AddNote?format=camel"
        payload = {
            "author": self.params.author,
            "content": self.params.content,
            "entityIdentifier": self.params.entity_identifier,
            "id": self.params.entity_id,
            "entityEnvironment": self.params.entity_environment,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def assign_case_to_user(self) -> requests.Response:
        """Assign case to user"""
        endpoint = "api/external/v1/cases/AssignUserToCase"
        payload = {
            "caseId": self.params.case_id,
            "alertIdentifier": self.params.alert_identifier,
            "userId": self.params.assign_to,
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

    def get_email_template(self) -> requests.Response:
        """Get email template"""
        endpoint = "api/external/v1/settings/GetEmailTemplateRecords?format=camel"
        return self._make_request(HttpMethod.GET, endpoint)

    def get_siemplify_user_details(self) -> requests.Response:
        """Get siemplify user details"""
        endpoint = "https://localhost:8443/api/external/v1/settings/GetUserProfiles"
        payload = {
            "searchTerm": self.params.search_term,
            "filterRole": self.params.filter_by_role,
            "requestedPage": self.params.requested_page,
            "pageSize": self.params.page_size,
            "shouldHideDisabledUsers": self.params.should_hide_disabled_users
        }
        return self._make_request(HttpMethod.POST, endpoint, json_payload=payload)

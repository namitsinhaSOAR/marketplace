# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from requests import Session


class SiemplifySession(Session):
    def __init__(self, sensitive_data_arr=[]):
        Session.__init__(self)
        self.sensitive_data_arr = sensitive_data_arr

    def request(self, method, url, **kwargs):
        try:
            return super(SiemplifySession, self).request(method, url, **kwargs)
        except Exception as e:
            err_msg = str(e)
            try:
                e.args = map(lambda err: self.encode_sensitive_data(err), e.args)
                e.message = self.encode_sensitive_data(err_msg)
            except Exception:
                raise Exception(self.encode_sensitive_data(err_msg))
            raise

    def encode_sensitive_data(self, message):
        """
        Encode sensitive data
        :param message: {str} The error message which may contain sensitive data
        :return: {str} The error message with encoded sensitive data
        """
        for sensitive_data in self.sensitive_data_arr:
            message = message.replace(sensitive_data, self.encode_data(sensitive_data))
        return message

    @staticmethod
    def encode_data(sensitive_data):
        """
        Encode string
        :param sensitive_data: {str} String to be encoded
        :return: {str} Encoded string
        """
        if len(sensitive_data) > 1:
            return u"{}...{}".format(sensitive_data[0], sensitive_data[-1])
        return sensitive_data
